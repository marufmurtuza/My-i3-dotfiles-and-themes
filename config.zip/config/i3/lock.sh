#!/bin/bash

# scrot desktop and lock screen
scrot /tmp/screen_locked.png
i3lock -i /tmp/screen_locked.png
